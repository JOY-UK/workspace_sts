package com.green.CarInfo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarInfoApplicationTests {

	@Test
	void contextLoads() {
	}

}
